package com.bookshopweb.utils;

public interface ConstantUtils {
    int DB_PORT = 3306;
    String SERVER_NAME = "localhost";
    String DB_NAME = "bookshopdb";
    String DB_USERNAME = "root";
    String DB_PASSWORD = "Vantu16022003";
    String IMAGE_PATH = "/var/webapp/images"; // Dùng "C:\\var\\webapp\\images" trên Windows
}
